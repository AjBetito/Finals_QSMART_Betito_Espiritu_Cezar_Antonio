from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('signup/', views.signup, name="signup"),
    path('signin/', views.signin, name="signin"),
    path('signout/', views.signout, name="signout"),
    path('dashboard/', views.dashboard, name="dashboard"),
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    path('student/signup/', views.student_signup, name='student_signup'),
    path('operator/signup/', views.operator_signup, name='operator_signup'),
    path('student/signin/', views.student_signin, name='student_signin'),
    path('operator/signin/', views.operator_signin, name='operator_signin'),
    #path('QSMART UI Options 2.html', views.qsmart_ui_options_2, name='qsmart_ui_options_2'),
    #path('QSMART UI Options.html', views.qsmart_ui_options_2, name='qsmart_ui_options_'),
]