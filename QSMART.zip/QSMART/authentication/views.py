from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import UserProfile

def home(request):
    return render(request, "authentication/index.html")

def signup(request):
    if request.method == "POST":

        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        role = request.POST.get('role', '') 

        if not all([name, email, password, confirm_password]):
            messages.error(request, "Please fill out all the fields.")
            return render(request, "authentication/signup_student.html")

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, "authentication/signup_student.html")

        if User.objects.filter(username=email).exists():
            messages.error(request, "Email is already taken.")
            return render(request, "authentication/signup_student.html")

        user = User.objects.create_user(username=email, email=email, password=password)
        user.first_name = name
        user.role = role
        user.save()

        messages.success(request, "Your account has been successfully created.")
        return redirect('signin')
    
    return render(request, "authentication/signup_student.html")

def student_signup(request):
    if request.method == "POST":

        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if not all([name, email, password, confirm_password]):
            messages.error(request, "Please fill out all the fields.")
            return render(request, "authentication/signup_student.html")

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, "authentication/signup_student.html")

        if User.objects.filter(username=email).exists():
            messages.error(request, "Email is already taken.")
            return render(request, "authentication/signup_student.html")

        user = User.objects.create_user(username=email, email=email, password=password)
        user.first_name = name
        user.save()

        profile = UserProfile(user=user, role='student')
        profile.save()

        messages.success(request, "Your account has been successfully created.")
        return redirect('student_signin')
    
    return render(request, 'authentication/signup_student.html')

def operator_signup(request):
    if request.method == "POST":

        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if not all([name, email, password, confirm_password]):
            messages.error(request, "Please fill out all the fields.")
            return render(request, "authentication/signup_operator.html")

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return render(request, "authentication/signup_operator.html")

        if User.objects.filter(username=email).exists():
            messages.error(request, "Email is already taken.")
            return render(request, "authentication/signup_operator.html")

        user = User.objects.create_user(username=email, email=email, password=password)
        user.first_name = name
        user.save()

        profile = UserProfile(user=user, role='operator')
        profile.save()

        messages.success(request, "Your account has been successfully created.")
        return redirect('operator_signin')
    
    return render(request, 'authentication/signup_operator.html')

def signin(request):
    if request.method == 'POST':
        email = request.POST.get('email') 
        password = request.POST.get('password') 

        user = authenticate(request, username=email, password=password)

        if user is not None:
            login(request, user)
            return redirect('dashboard') 
        else:
            messages.error(request, "Bad Credentials.")
            return redirect('signin')

    return render(request, "authentication/signin.html")

@login_required                         # Edit logic
def dashboard(request):
    return render(request, "authentication/dashboard.html")

def signout(request):
    logout(request)
    messages.info(request, "You have signed out.")
    return redirect('student_signin')

def student_signin(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        user = authenticate(request, username=email, password=password)
        
        if user is not None:
            profile = UserProfile.objects.get(user=user)
            if profile.role == 'student':
                login(request, user)
                return redirect('student_dashboard') 
            else:
                messages.error(request, "You are not authorized to sign in as a student.")
        else:
            messages.error(request, "Invalid credentials.")
    
    return render(request, "authentication/signin_student.html")

def operator_signin(request):
    if request.method == 'POST':
        # extract email and password from the form
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        # authenticate the user
        user = authenticate(request, username=email, password=password)
        
        if user is not None:            #buggy asf
            if user.role == 'operator':
                login(request, user)
                return redirect('operator_dashboard')
            else:
                messages.error(request, "You are not authorized to sign in as an operator.")
                return redirect('operator_signup')
        else:
            return redirect('operator_signup')

    return render(request, "authentication/signin_operator.html")
    
def student_dashboard(request):
    return render(request, 'authentication/student_dashboard.html')
